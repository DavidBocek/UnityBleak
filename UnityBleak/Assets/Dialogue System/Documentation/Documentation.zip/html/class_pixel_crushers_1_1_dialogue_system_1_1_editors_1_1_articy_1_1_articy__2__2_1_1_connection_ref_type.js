var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_connection_ref_type =
[
    [ "IdRef", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_connection_ref_type.html#a9957fc34d5a1938b6d2d1d540f94776d", null ],
    [ "PinRef", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_connection_ref_type.html#a7b36464f126d1602f3ea41432a035785", null ],
    [ "Value", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_connection_ref_type.html#a319eb6498b854c6c564478dae7d6b651", null ]
];