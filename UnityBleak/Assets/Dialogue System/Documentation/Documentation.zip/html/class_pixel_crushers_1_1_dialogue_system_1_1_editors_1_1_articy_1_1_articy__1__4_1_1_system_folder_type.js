var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_system_folder_type =
[
    [ "Color", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_system_folder_type.html#ac4ffc58a1ae075856cdddf0c2941bd6b", null ],
    [ "DisplayName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_system_folder_type.html#ae93b1f7e9d0a142c49b84da2b1ac98af", null ],
    [ "Guid", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_system_folder_type.html#a194cd9b88fb8217f6a6e5f5b55e432ff", null ]
];