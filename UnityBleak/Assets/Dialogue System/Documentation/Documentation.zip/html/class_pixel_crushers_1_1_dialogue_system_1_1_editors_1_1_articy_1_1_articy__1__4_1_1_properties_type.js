var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_properties_type =
[
    [ "Count", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_properties_type.html#aa28772826f2691db9d692f6aa27143f3", null ],
    [ "Items", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_properties_type.html#a20aecfe0f8374d0ff5fd7e3bb6521dce", null ]
];