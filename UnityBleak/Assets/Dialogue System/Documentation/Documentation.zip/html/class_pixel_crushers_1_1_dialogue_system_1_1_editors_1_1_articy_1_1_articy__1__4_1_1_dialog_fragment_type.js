var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_dialog_fragment_type =
[
    [ "Color", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_dialog_fragment_type.html#aec7623b8deb6fafb908f0a73809b2f47", null ],
    [ "DisplayName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_dialog_fragment_type.html#a86affc903712342a2ded68fed917f491", null ],
    [ "Entity", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_dialog_fragment_type.html#ab7c972ec0b005f81df5b876d0b7ec826", null ],
    [ "ExternalId", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_dialog_fragment_type.html#a6aabcf802c14adab4facb0de8a479aba", null ],
    [ "Features", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_dialog_fragment_type.html#a3f5bc2278527b098a5ac2cddaab3c285", null ],
    [ "Guid", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_dialog_fragment_type.html#aaae04c6a87ce5637e04df5785c283fdb", null ],
    [ "ObjectTemplateReference", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_dialog_fragment_type.html#ab3f3010128ab5115cb0c28e9507c4cd3", null ],
    [ "ObjectTemplateReferenceName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_dialog_fragment_type.html#ad6c44ffe1216088bf16e466f7cdc7696", null ],
    [ "Pins", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_dialog_fragment_type.html#acba11d02f90c10660680b5839cdf5441", null ],
    [ "PreviewText", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_dialog_fragment_type.html#a4c599fb7a2b293f4e85c3c5fbb25f7b1", null ],
    [ "ShortId", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_dialog_fragment_type.html#af9dc9a7eb640c8b3afe2119ae8eb6a6f", null ],
    [ "StageDirections", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_dialog_fragment_type.html#af1bea8eb92b75fa6b93c0a8b5d74cd12", null ],
    [ "TechnicalName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_dialog_fragment_type.html#a1f476034af5fc36dbd4407785519916d", null ],
    [ "Text", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_dialog_fragment_type.html#a08b87ace54c500ef392e001be8d90382", null ]
];