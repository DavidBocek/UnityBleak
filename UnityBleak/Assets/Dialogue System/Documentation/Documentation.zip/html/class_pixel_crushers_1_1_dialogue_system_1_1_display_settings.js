var class_pixel_crushers_1_1_dialogue_system_1_1_display_settings =
[
    [ "AlertSettings", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_alert_settings.html", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_alert_settings" ],
    [ "CameraSettings", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_camera_settings.html", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_camera_settings" ],
    [ "InputSettings", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_input_settings.html", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_input_settings" ],
    [ "LocalizationSettings", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_localization_settings.html", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_localization_settings" ],
    [ "SubtitleSettings", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_subtitle_settings.html", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_subtitle_settings" ],
    [ "alertSettings", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings.html#a8795e3fa3fed2929e4b4788d55421959", null ],
    [ "cameraSettings", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings.html#abc978a051dfd11f1b47ef2842fb94205", null ],
    [ "dialogueUI", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings.html#a7f492a10af411c906c8bf5f5134319e4", null ],
    [ "inputSettings", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings.html#a5b21a751ca36a2643790aaae64e0ed1d", null ],
    [ "localizationSettings", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings.html#a9e7e4db0781ded668cd4a66d5dea007d", null ],
    [ "subtitleSettings", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings.html#ae8bd287266b67449aaa7af0e23cb1f8c", null ]
];