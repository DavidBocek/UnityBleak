var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_journey_ref_type =
[
    [ "GuidRef", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_journey_ref_type.html#a401ded67ab6b6c537f25aadb8e5bb2ee", null ],
    [ "PinRef", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_journey_ref_type.html#a97f84ce98f691ac9eaff06ac48553813", null ],
    [ "Value", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_journey_ref_type.html#ac5e10a7e8ff987a8843fb3b7dd607bdc", null ]
];