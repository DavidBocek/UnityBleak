var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_project =
[
    [ "createdOn", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_project.html#a529c773673086797fa512e7fab75739f", null ],
    [ "creatorTool", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_project.html#aaa377015c652882edfd2ebcf57c674ab", null ],
    [ "creatorVersion", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_project.html#a5f5b7a972ed73a1c5a1e900c8c79221e", null ],
    [ "displayName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_project.html#a89bcc3adde576fca2f47b0600cadae02", null ]
];