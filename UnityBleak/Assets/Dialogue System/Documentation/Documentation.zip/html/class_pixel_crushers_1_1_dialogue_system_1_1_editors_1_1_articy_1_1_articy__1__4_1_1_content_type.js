var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_content_type =
[
    [ "Items", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_content_type.html#a5768804afbbbbedae6c625ded360e126", null ],
    [ "ItemsElementName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_content_type.html#ac1775c7bacf2b38158d556ee1c4674ae", null ]
];