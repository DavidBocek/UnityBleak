var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_element =
[
    [ "Element", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_element.html#a6601ae6b3ad614ee3680d7a67535a2d2", null ],
    [ "Element", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_element.html#a73c6770f56fd087378f20a8fe0ff0b46", null ],
    [ "displayName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_element.html#a8a79cc6cffa0289052b37e941df96c07", null ],
    [ "id", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_element.html#ab55cd75ae251a82613bf9b3ba677f549", null ],
    [ "technicalName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_element.html#a803d2bb3aa086db1e06d4a25e7ad933e", null ],
    [ "text", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_element.html#a5303ade2ed7d895e5df1e989cd5ecd70", null ]
];