var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_object_template_definition_type =
[
    [ "Color", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_object_template_definition_type.html#ad6e4dd9abb2c06a9c8abb217345d4687", null ],
    [ "DisplayName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_object_template_definition_type.html#ae2e69100aa1baa72a7095b0a4e0389d1", null ],
    [ "ExternalId", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_object_template_definition_type.html#a83c2bfd0bfde05dfd2d6152115c0371f", null ],
    [ "FeatureDefinitions", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_object_template_definition_type.html#a0b16b25558e94ce7f389f3a83762fec1", null ],
    [ "Guid", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_object_template_definition_type.html#a9882f4b7999a02f615e822934146f735", null ],
    [ "ShortId", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_object_template_definition_type.html#ab64a0933d6e068d5ab477e8b467f14a7", null ]
];