var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_enum_property_type =
[
    [ "Name", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_enum_property_type.html#aa1a2f1d1b9a6f40a4dfd704eebcf1800", null ],
    [ "Value", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_enum_property_type.html#adf9bcdc4cd32d70fbca334a45939824a", null ]
];