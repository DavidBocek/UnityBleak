var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_spot_type =
[
    [ "Color", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_spot_type.html#a84672860ab9754489cf5de1403b95b18", null ],
    [ "DisplayName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_spot_type.html#a4a91f4a554efdc47268668e035250e4d", null ],
    [ "ExternalId", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_spot_type.html#a1ee17cb7fe7e90f57401b78586b0124d", null ],
    [ "Features", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_spot_type.html#a008d0626ebe09622756b2cf71093f4be", null ],
    [ "Guid", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_spot_type.html#a0b6be50b74bd854c873ba46b926775b2", null ],
    [ "ObjectTemplateReference", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_spot_type.html#af7c7d13a453d49ce74002efb7a5a0089", null ],
    [ "ObjectTemplateReferenceName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_spot_type.html#a3ef0747b447b7c32d5e93b641e15ccb1", null ],
    [ "PreviewImage", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_spot_type.html#a5a080850524137a7e3991775f63bfda0", null ],
    [ "ShortId", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_spot_type.html#a8db789235c2556fb44e9cda18dd65e07", null ],
    [ "TechnicalName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_spot_type.html#ac8dab995630dade57e2b47d5dfd27b4f", null ],
    [ "Text", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_spot_type.html#a5eae82b86d1d0bde5ea0afcdfa7e9a74", null ],
    [ "X", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_spot_type.html#a8a52144e16a6b04f48ee3975309f1a3e", null ],
    [ "Y", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_spot_type.html#a32e1a52a2064f050818449ef10a603e1", null ]
];