var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_feature_definition_type =
[
    [ "BasedOn", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_feature_definition_type.html#afc29842dc0c14f1dbe27ec5cb913223b", null ],
    [ "Color", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_feature_definition_type.html#a8fced5f2b8cfa00abe9e16340508ae7f", null ],
    [ "DisplayName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_feature_definition_type.html#ae3bef5954db1cd3d0c44305c5eef7ff7", null ],
    [ "ExternalId", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_feature_definition_type.html#a1fa740320be2ecaed4199d9d0e804e1c", null ],
    [ "Guid", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_feature_definition_type.html#a0b291ad82b0364a04cda3d278d4995ab", null ],
    [ "PropertyDefinitions", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_feature_definition_type.html#a375b8bc8b696c682e57a61a571389276", null ],
    [ "ShortId", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_feature_definition_type.html#a8ce9d272b4f13b98dee2649da2eda176", null ],
    [ "TechnicalName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_feature_definition_type.html#ae2a218425a9577fe7d805f51a1235a1a", null ],
    [ "Text", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_feature_definition_type.html#ad75a78132a4d582a51d7eb64615df7db", null ]
];