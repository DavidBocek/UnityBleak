var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_boolean_property_definition_type =
[
    [ "BasedOn", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_boolean_property_definition_type.html#aba8af6a5001581a345a73fdb06343396", null ],
    [ "DefaultValue", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_boolean_property_definition_type.html#a07450969670d08bd7b76f90a7ccb3706", null ],
    [ "DefaultValueSpecified", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_boolean_property_definition_type.html#ae93791ae4dd6f6a8cb3f33b0cfaf2245", null ],
    [ "DisplayName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_boolean_property_definition_type.html#a6386df92b1f83fb2ae7ab3fb89c15975", null ],
    [ "Guid", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_boolean_property_definition_type.html#a865a474c2c06863032cfd6ba0074af3f", null ],
    [ "IsLocalized", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_boolean_property_definition_type.html#a1ca18d65d290305c68a3adeb94071dd1", null ],
    [ "IsLocalizedSpecified", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_boolean_property_definition_type.html#ac1840ec51df8337e64868029f17664ff", null ],
    [ "IsMandatory", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_boolean_property_definition_type.html#a3010f713728ba1ecd49f2c48cffe8abb", null ],
    [ "IsMandatorySpecified", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_boolean_property_definition_type.html#ae5bcd10bdc11e9bb6a1bc92e8d16aaca", null ],
    [ "PlaceholderValue", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_boolean_property_definition_type.html#a64fb8cc9980ef2aa7988faf3d29ea5b0", null ],
    [ "TechnicalName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_boolean_property_definition_type.html#a535698e0b89ca13bcadf22a06c58ac11", null ],
    [ "TooltipText", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_boolean_property_definition_type.html#a9caf9ee7242795677365e385587b5f2c", null ]
];