var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_named_reference_type =
[
    [ "GuidRef", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_named_reference_type.html#a2d02255149f75da5233d3413bfb7b8ac", null ],
    [ "Name", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_named_reference_type.html#ab24500b366be6cd1e280089cacfbd411", null ],
    [ "Value", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_named_reference_type.html#a801fdedd39e3a0c4f8a466884109a50e", null ]
];