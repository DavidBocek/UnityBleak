var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_localizable_text =
[
    [ "localizedString", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_localizable_text.html#a89069b509ea32a1a1a3fd05564c1adaf", null ],
    [ "DefaultText", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_localizable_text.html#a495c47d2acd471bdb4fbee6ea5e0262d", null ]
];