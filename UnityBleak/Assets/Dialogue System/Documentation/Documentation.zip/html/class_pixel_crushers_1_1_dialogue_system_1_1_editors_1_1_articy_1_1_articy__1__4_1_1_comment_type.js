var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_comment_type =
[
    [ "Color", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_comment_type.html#a36e550bac242d9af021471abd1f4f1b5", null ],
    [ "CreatedBy", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_comment_type.html#a712e3b48707bd01b5ff8a4bff9df1f9a", null ],
    [ "CreatedOn", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_comment_type.html#ab304bbc8fb6fe3559ceb105f18b47cf6", null ],
    [ "Guid", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_comment_type.html#ab391a2060c6ed2ea8760c82039a876b0", null ],
    [ "Text", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_comment_type.html#a094e16224e66cb8ba60b57bdce4a0837", null ]
];