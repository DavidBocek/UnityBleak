var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_localized_string_type =
[
    [ "Lang", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_localized_string_type.html#abcbdcaea45560ed6188b8e3c706766b9", null ],
    [ "Value", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_localized_string_type.html#a1434fb4c701adff026c7567154e2c8a1", null ]
];