var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_variable_set =
[
    [ "VariableSet", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_variable_set.html#a7c9277dd1f91fe0136e43ac9aa8816a4", null ],
    [ "VariableSet", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_variable_set.html#a0ed2f0a280238a06af08a2ecafd976da", null ],
    [ "id", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_variable_set.html#a896ab39ecc433f1c1de1fb63fd91a51d", null ],
    [ "technicalName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_variable_set.html#a03f14a7c05ab4f974e56f215db042deb", null ],
    [ "variables", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_variable_set.html#aa2783f6043f62927bde09ef23face9f4", null ]
];