var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_variable =
[
    [ "Variable", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_variable.html#ad99715bb96bb262018b0adf6c784bb58", null ],
    [ "Variable", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_variable.html#ab7ce25451a84f06f4c89d28de7b21df7", null ],
    [ "dataType", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_variable.html#ad7b6b6b05b46c59958386d6566f12c7b", null ],
    [ "defaultValue", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_variable.html#aec2174b4dba2dbb331dd88b1f0a2d6c1", null ],
    [ "technicalName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_variable.html#aa932ccd15e26f1bbd90e3cf1c540b15e", null ]
];