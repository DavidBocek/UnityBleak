var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_comment_type =
[
    [ "Color", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_comment_type.html#a3a22e5bc123164de39ea4f3a1598c96f", null ],
    [ "CreatedBy", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_comment_type.html#a528bb04da71c56611f2b84156291e5c2", null ],
    [ "CreatedOn", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_comment_type.html#afc8e20ea0581d52cc5ffd152494ba6c9", null ],
    [ "Id", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_comment_type.html#a030c3f7b64a199527819880ea0d49ddd", null ],
    [ "Text", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_comment_type.html#a8e627da4038a8837f61b2eae10195388", null ]
];