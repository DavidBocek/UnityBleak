var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_number_property_definition_type =
[
    [ "BasedOn", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_number_property_definition_type.html#a58848890ed595dad255875a747a6ca3c", null ],
    [ "DefaultValue", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_number_property_definition_type.html#a52a2fc4035a60d2c4cdbd9d2fb691763", null ],
    [ "DefaultValueSpecified", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_number_property_definition_type.html#a5e49cbc4d8f1853b2c7ad461ee53f858", null ],
    [ "DisplayName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_number_property_definition_type.html#ab4d31ade637095745496a7c368a4f0d1", null ],
    [ "DisplayThousandsSeparator", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_number_property_definition_type.html#a6790868e9cf597e7fd58a9ad8a86f8bb", null ],
    [ "DisplayThousandsSeparatorSpecified", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_number_property_definition_type.html#a5842478f1427f264e9f1f06297b85022", null ],
    [ "Guid", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_number_property_definition_type.html#ad4fc4a344dce180edbd92a986337c306", null ],
    [ "IsLocalized", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_number_property_definition_type.html#a6b1af615bfdae4212074ad76cbebb8bf", null ],
    [ "IsLocalizedSpecified", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_number_property_definition_type.html#a7073a7fe2c8efed69ff86bc2d6841138", null ],
    [ "IsMandatory", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_number_property_definition_type.html#ad1eabd16ac52f1479d131c802a901598", null ],
    [ "IsMandatorySpecified", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_number_property_definition_type.html#ad7e81137e6c080c1e21a8f0efdfa6247", null ],
    [ "MaxValue", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_number_property_definition_type.html#ab6f5e95258be131a76e599441a6936a4", null ],
    [ "MaxValueSpecified", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_number_property_definition_type.html#a9f3a33cad8a47619c3566e7a1d4ee369", null ],
    [ "MinValue", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_number_property_definition_type.html#a98b707361be407fd74ff901f8cfb037b", null ],
    [ "MinValueSpecified", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_number_property_definition_type.html#a3a7f21bf221be3bc7a27c4516ffc115f", null ],
    [ "PlaceholderValue", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_number_property_definition_type.html#a5f35f22c1bcd25d98f876e5783dad625", null ],
    [ "Precision", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_number_property_definition_type.html#a9112fabff4adfd8a7d35b8fbdc40ccc1", null ],
    [ "PrecisionSpecified", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_number_property_definition_type.html#a0b08fdcd4cc20a908180ab59e2db3c0e", null ],
    [ "TechnicalName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_number_property_definition_type.html#a20cd763c5ff36ff36445780330714691", null ],
    [ "TooltipText", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_number_property_definition_type.html#a013100517c2a740abd5ff2d0c5ec98b1", null ],
    [ "Unit", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_number_property_definition_type.html#adae43bf2e912b5c447395e58ec4bfaf0", null ]
];