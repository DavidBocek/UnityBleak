var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_references_type =
[
    [ "Count", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_references_type.html#a9f02439efab930f3ef8ae37c1273c185", null ],
    [ "Reference", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_references_type.html#a79b7a1bef07a42f819f0d9b21edbe95e", null ]
];