var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_pins_type =
[
    [ "Count", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_pins_type.html#a618edc2022f19c5e0d9ac6f256921b7a", null ],
    [ "Pin", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_pins_type.html#aeb83c4f08fb7b82d9e6481060fd8a0df", null ]
];