var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_asset_type =
[
    [ "AssetFilename", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_asset_type.html#a71b01978052729efe91cf2fb97c60e72", null ],
    [ "AssetPath", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_asset_type.html#a303a16c4f8d8aff3a889aefff33d746e", null ],
    [ "Color", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_asset_type.html#a332b6f073b9c164506f6aefda7fa0e9a", null ],
    [ "DisplayName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_asset_type.html#a4ea561b7cfc96d06737faa28a7913cb0", null ],
    [ "ExternalId", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_asset_type.html#ad18b2aa1e68f69e3c8d420261807fe0b", null ],
    [ "Features", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_asset_type.html#a6273a7c905da8bda1c7e8332507c155a", null ],
    [ "Guid", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_asset_type.html#a279edb4433049f91906f8d88b971786e", null ],
    [ "ObjectTemplateReference", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_asset_type.html#a8ea4d1e8b472141d2d3871f0eb42cda4", null ],
    [ "ObjectTemplateReferenceName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_asset_type.html#a84722a18597ff138d69d67367c022922", null ],
    [ "OriginalSource", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_asset_type.html#a52ad64328eb4b7c785f9eee9a62f4bb3", null ],
    [ "PreviewImage", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_asset_type.html#a9e986fb90b36bee24023657369d1b634", null ],
    [ "ShortId", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_asset_type.html#adf50127000d02cbc3fca61d28262650f", null ],
    [ "TechnicalName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_asset_type.html#a44a1db9db58d1417f23ef0b2efa1b33c", null ],
    [ "Text", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_asset_type.html#aeda725c501c3c7954379083a6ace00d4", null ]
];