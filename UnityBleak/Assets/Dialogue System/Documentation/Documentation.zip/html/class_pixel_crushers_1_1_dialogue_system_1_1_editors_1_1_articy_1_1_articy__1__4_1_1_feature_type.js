var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_feature_type =
[
    [ "GuidRef", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_feature_type.html#ab6ca30edac2ee174ac24b7e1581c2eaa", null ],
    [ "Name", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_feature_type.html#a7c6c0d421b8093b5c19ad86257616237", null ],
    [ "Properties", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_feature_type.html#a8c0338581c60b9a8f4cdb8964d484291", null ]
];