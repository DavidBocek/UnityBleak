var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_connection_type =
[
    [ "Color", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_connection_type.html#aca0ba7a4c3758515a03494c6d2afdd78", null ],
    [ "Id", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_connection_type.html#a46ab4608cd007ea176abd3e409c1ace7", null ],
    [ "Label", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_connection_type.html#a138f9e4678c5d9a1dd3af07626f772b3", null ],
    [ "Source", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_connection_type.html#a6c13590c7163016b22c328f916fe14b4", null ],
    [ "Target", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_connection_type.html#a5466db044e380e17eb7debf6727750fe", null ],
    [ "TechnicalName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_connection_type.html#a5f8929278b9ff698a2c643f1520fc8aa", null ]
];