var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_zone_type =
[
    [ "Color", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_zone_type.html#ac1f96f578ff93b70a99c14c484772cd2", null ],
    [ "DisplayName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_zone_type.html#a21b92326bdcd9f35565e1ff6d9db355c", null ],
    [ "ExternalId", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_zone_type.html#ad04c17cba86b54a40325abd6751d31f5", null ],
    [ "Features", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_zone_type.html#aafd761317d553b897a58dbf9c9f90f44", null ],
    [ "Guid", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_zone_type.html#a24f38233f8fd5663b8d4e2943cf0826f", null ],
    [ "Item", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_zone_type.html#aa3295b25f0318cfeeaac0acf78a5fa2f", null ],
    [ "ObjectTemplateReference", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_zone_type.html#ac35d8b040a6d2aa0db833ec7167d5a02", null ],
    [ "ObjectTemplateReferenceName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_zone_type.html#a248734e8c0ab24f7a9992575a9a2a205", null ],
    [ "PreviewImage", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_zone_type.html#ae8c55c5a265140e3343ac22ccb321b0e", null ],
    [ "Shape", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_zone_type.html#a07fc2d04718ab84fc41cea05e522dd14", null ],
    [ "ShortId", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_zone_type.html#a0f520fd72582c9812e9ae314c31392c9", null ],
    [ "TechnicalName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_zone_type.html#aadbf18d03e28b89e48a67f995dbc1ae5", null ],
    [ "Text", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_zone_type.html#a2f4b16be3429033f8a4018c4611e7fa2", null ],
    [ "X", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_zone_type.html#adb937c7fd5c7430f79fe278316e05ef5", null ],
    [ "Y", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_zone_type.html#adda882365b389c61459079f0e8beb6da", null ]
];