var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_enum_value_type =
[
    [ "DisplayName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_enum_value_type.html#a0f771fd1220600a771bb18095431b4c8", null ],
    [ "TechnicalName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_enum_value_type.html#aa77c8213640882c93d459790c501dce4", null ],
    [ "Value", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_enum_value_type.html#a2bc96e027ae675fd44dd247a1ffc5d5d", null ]
];