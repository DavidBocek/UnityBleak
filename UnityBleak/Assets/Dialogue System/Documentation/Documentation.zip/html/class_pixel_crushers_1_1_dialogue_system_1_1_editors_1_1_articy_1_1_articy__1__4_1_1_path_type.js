var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_path_type =
[
    [ "Color", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_path_type.html#afbe8f1d60a7eb0352a9c169da66fb2f7", null ],
    [ "DisplayName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_path_type.html#a5e96ba62446c45ba790f70248e447df0", null ],
    [ "ExternalId", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_path_type.html#aaebc9408b8f7dbd277767b2a11d9ae9b", null ],
    [ "Features", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_path_type.html#a5a430442afd4c4291ea2c40847851801", null ],
    [ "Guid", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_path_type.html#a9821f98caaa712333881571febda6962", null ],
    [ "ObjectTemplateReference", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_path_type.html#a0b688a9989379cf9cb5962fbb9320ad9", null ],
    [ "ObjectTemplateReferenceName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_path_type.html#abfb222399fc1823292ddce2c9e26c9d0", null ],
    [ "PreviewImage", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_path_type.html#a8b93391c6c570fd2c60ec44553747976", null ],
    [ "ShortId", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_path_type.html#a3385419e8869f27c56f98da890020464", null ],
    [ "TechnicalName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_path_type.html#a3d8da3fb4a445edb790faf97f9b016f2", null ],
    [ "Text", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_path_type.html#afb233ed494182deb8aec5d2ac8da0d61", null ],
    [ "Vertices", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_path_type.html#a3428a248c6e085ff69b741f813160e5a", null ],
    [ "X", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_path_type.html#a719d5ac669e3ad744d40ae96648daa40", null ],
    [ "Y", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_path_type.html#a1bbf20ffa36dc1f095a9fca0de92c84f", null ]
];