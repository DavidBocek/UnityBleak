var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_allowed_template =
[
    [ "GuidRef", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_allowed_template.html#a94b25405acb8463715969d80ddcad33b", null ],
    [ "Name", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_allowed_template.html#a226ea1596002d23380da315136cc169f", null ]
];