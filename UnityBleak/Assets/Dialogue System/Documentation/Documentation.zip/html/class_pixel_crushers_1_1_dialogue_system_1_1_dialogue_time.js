var class_pixel_crushers_1_1_dialogue_system_1_1_dialogue_time =
[
    [ "TimeMode", "class_pixel_crushers_1_1_dialogue_system_1_1_dialogue_time.html#af639fc8748d6a90e50c00abe96092834", [
      [ "Realtime", "class_pixel_crushers_1_1_dialogue_system_1_1_dialogue_time.html#af639fc8748d6a90e50c00abe96092834aa5ff58bda67e2160b5e5d5a47a4333c3", null ],
      [ "Gameplay", "class_pixel_crushers_1_1_dialogue_system_1_1_dialogue_time.html#af639fc8748d6a90e50c00abe96092834a6288740a1cd0de37312619df3b6ddcf3", null ]
    ] ],
    [ "Mode", "class_pixel_crushers_1_1_dialogue_system_1_1_dialogue_time.html#af02b045506fff3c5fc63ee3c82c4e41a", null ],
    [ "time", "class_pixel_crushers_1_1_dialogue_system_1_1_dialogue_time.html#af794f82b6b594e9302553c45f6593ffd", null ]
];