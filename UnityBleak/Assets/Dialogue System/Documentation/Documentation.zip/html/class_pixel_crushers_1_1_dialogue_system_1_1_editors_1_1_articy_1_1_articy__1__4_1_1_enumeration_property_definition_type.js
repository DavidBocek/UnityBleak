var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_enumeration_property_definition_type =
[
    [ "BasedOn", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_enumeration_property_definition_type.html#a910a28824dc9f626fb2b18228f453cf7", null ],
    [ "DefaultValue", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_enumeration_property_definition_type.html#a7abf9ca77c81a4406717eb1aaddb01c1", null ],
    [ "DefaultValueSpecified", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_enumeration_property_definition_type.html#a26ca307bd4eab8408ec2e6afe742751d", null ],
    [ "DisplayName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_enumeration_property_definition_type.html#a10c8190b36dd4c266a161deb23777cc7", null ],
    [ "Guid", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_enumeration_property_definition_type.html#a65004eeb6ab7509047459b73b8c3406f", null ],
    [ "IsLocalized", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_enumeration_property_definition_type.html#a9c12b6643b3cd2e19322e01c4759799b", null ],
    [ "IsLocalizedSpecified", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_enumeration_property_definition_type.html#ad9bb1c422d0a3c0bd7a91efbf7307315", null ],
    [ "IsMandatory", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_enumeration_property_definition_type.html#aebab21b928308cde304bcc5660a040cc", null ],
    [ "IsMandatorySpecified", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_enumeration_property_definition_type.html#a6f5b09602f39d78dba12ba3464995bde", null ],
    [ "PlaceholderValue", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_enumeration_property_definition_type.html#a394e2c22db714f48e76c5393b75b5b41", null ],
    [ "TechnicalName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_enumeration_property_definition_type.html#a81286d4f3e6288c3eeafed05211df962", null ],
    [ "TooltipText", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_enumeration_property_definition_type.html#a0256bc648ca2233a900784089e2c37d5", null ],
    [ "Values", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_enumeration_property_definition_type.html#a6488bc6d031241cc999f82719e841a74", null ]
];