var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_journey_settings_type =
[
    [ "BackgroundColor", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_journey_settings_type.html#a9470bf0b497476c0c461410d288fa960", null ],
    [ "BackgroundColorGradientMode", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_journey_settings_type.html#adbecfa0e00db1d6aef0b501e8df4ece1", null ],
    [ "BackgroundColorMode", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_journey_settings_type.html#a1e2e95fcdffe8346f20b83c0551e5cfc", null ],
    [ "BackgroundImage", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_journey_settings_type.html#ac062cfb01cbe1fbfc04a5f7851747c46", null ],
    [ "BackgroundImageMode", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_journey_settings_type.html#a372e8945168ed6ae7d0c5c431fa73da5", null ],
    [ "BackgroundImagePositioningMode", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_journey_settings_type.html#a0b8927eb69e26fe0131be519b1b2aead", null ],
    [ "Duration", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_journey_settings_type.html#acab75caeadaee4ddafe38ea9c772279e", null ],
    [ "TransitionMode", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_journey_settings_type.html#a13f638c8a54e2995e547865d826cf3e4", null ]
];