var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_node =
[
    [ "Node", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_node.html#addceba3f5c0fe61734863caea46d53f5", null ],
    [ "Node", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_node.html#a63b72f5e779ddb81f44f1dc798d89349", null ],
    [ "id", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_node.html#aa5f8fc76ee88b4b555447db7263188c0", null ],
    [ "nodes", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_node.html#a1237fa9a6b76c512aaf73fccfa8fe6e5", null ],
    [ "type", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_node.html#a7c65342eb67b8686d7aaccac6f84f06c", null ]
];