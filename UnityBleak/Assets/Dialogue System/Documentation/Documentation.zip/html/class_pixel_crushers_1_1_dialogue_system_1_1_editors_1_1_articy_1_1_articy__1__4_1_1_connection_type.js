var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_connection_type =
[
    [ "Color", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_connection_type.html#a6c7f97867f1f291b645a8e53771482cb", null ],
    [ "Guid", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_connection_type.html#abf135aa13e76cbd6d3f4061c54d4b5f2", null ],
    [ "Label", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_connection_type.html#ae2b93090fd14ccd515f2f0d14f3c9224", null ],
    [ "Source", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_connection_type.html#a880478741c060f21acb5cb667b9dce3a", null ],
    [ "Target", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_connection_type.html#a938f0a68518c85984b91666c434944c3", null ],
    [ "TechnicalName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_connection_type.html#afd86fb9f05cc2fd5a33e49e6cf1daad8", null ]
];