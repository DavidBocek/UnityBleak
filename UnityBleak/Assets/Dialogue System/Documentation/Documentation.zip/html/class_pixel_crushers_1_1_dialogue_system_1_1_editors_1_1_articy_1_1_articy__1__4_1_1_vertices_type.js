var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_vertices_type =
[
    [ "Count", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_vertices_type.html#ae0c05d28902f0bd37ab1f10054810369", null ],
    [ "Value", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_vertices_type.html#ad94a6c44b5badde96b0c81cee6abd5f3", null ]
];