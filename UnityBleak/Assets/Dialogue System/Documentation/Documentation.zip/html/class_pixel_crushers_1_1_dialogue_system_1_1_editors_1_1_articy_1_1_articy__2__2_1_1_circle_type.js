var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_circle_type =
[
    [ "CenterX", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_circle_type.html#aef31242f6807a216ee5edbde756a9135", null ],
    [ "CenterY", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_circle_type.html#a15125ba0aefe63f6a70139a0d1afb7e9", null ],
    [ "Radius", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_circle_type.html#a4f8c5b71fc9860e728837b1db8f6a61f", null ]
];