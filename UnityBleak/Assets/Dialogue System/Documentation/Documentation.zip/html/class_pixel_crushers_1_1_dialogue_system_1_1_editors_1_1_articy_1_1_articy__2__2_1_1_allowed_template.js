var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_allowed_template =
[
    [ "IdRef", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_allowed_template.html#a7dc68806bf134eb2bdfc9603af72429b", null ],
    [ "Name", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_allowed_template.html#ac0b04e82b893a7c04b265a668094a019", null ]
];