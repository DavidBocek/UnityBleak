var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_content_type =
[
    [ "Items", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_content_type.html#a35af3623dd5299fbdcaf5da4feac595e", null ],
    [ "ItemsElementName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_content_type.html#a7f6aaaa68f070103a237cd6630c082c4", null ]
];