var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_boolean_property_definition_type =
[
    [ "BasedOn", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_boolean_property_definition_type.html#a489422cf4e8033503b59c853f4cd74f6", null ],
    [ "Color", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_boolean_property_definition_type.html#a6bcc192372b0e938d6ae9a1d1b2a108d", null ],
    [ "DefaultValue", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_boolean_property_definition_type.html#a30dc5099b30369cfe757e503a3bfa3ff", null ],
    [ "DefaultValueSpecified", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_boolean_property_definition_type.html#af0438dffd61b11aa5e1ffec14b081978", null ],
    [ "DisplayName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_boolean_property_definition_type.html#a9a668124dfb2cc59397b035cead7fcf6", null ],
    [ "Id", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_boolean_property_definition_type.html#abbf1bd441fff0dcdc214add2205cbaad", null ],
    [ "IsLocalized", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_boolean_property_definition_type.html#a0fbce3b5d47347382551546719c3a8c9", null ],
    [ "IsLocalizedSpecified", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_boolean_property_definition_type.html#a7945b0f45f04b5661d4303898fd7664d", null ],
    [ "IsMandatory", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_boolean_property_definition_type.html#aa5be81090592b2f2d30c94396acd1a31", null ],
    [ "IsMandatorySpecified", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_boolean_property_definition_type.html#a450f54c3015433672ed22f68c4b143bd", null ],
    [ "PlaceholderValue", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_boolean_property_definition_type.html#abb794e8c2d762ad4cd3edb9981c3be7d", null ],
    [ "TechnicalName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_boolean_property_definition_type.html#a6f66367cd583508dcf207d551198b2a1", null ],
    [ "TooltipText", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_boolean_property_definition_type.html#ad968c0b0396e45d9576e496c2c567eca", null ]
];