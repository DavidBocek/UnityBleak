var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_dialogue_fragment_type =
[
    [ "Color", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_dialogue_fragment_type.html#a71e5e2cb75671a915013dc79441e501b", null ],
    [ "DisplayName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_dialogue_fragment_type.html#a4ce52bc0868ed295e777d5cde75ed9fe", null ],
    [ "ExternalId", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_dialogue_fragment_type.html#ae0336101ac784c0a6aae73eff77fbc64", null ],
    [ "Features", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_dialogue_fragment_type.html#a6f8ff77d022882bfc028080787aaabb6", null ],
    [ "Id", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_dialogue_fragment_type.html#afa126d020e3cca67348a2c1819bf4421", null ],
    [ "MenuText", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_dialogue_fragment_type.html#a4eb457a8e2735731068be2a48ca211cf", null ],
    [ "ObjectTemplateReference", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_dialogue_fragment_type.html#aa088405c3d8085c1f46fc30d3b1fe7e6", null ],
    [ "ObjectTemplateReferenceName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_dialogue_fragment_type.html#a72fa3e0a745e9405b1ff6edfdb497e18", null ],
    [ "Pins", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_dialogue_fragment_type.html#a46a618f048716282294dddda6fd5e139", null ],
    [ "ShortId", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_dialogue_fragment_type.html#adb8675533f41942efa442338b68d5a19", null ],
    [ "Speaker", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_dialogue_fragment_type.html#a8769ac9bc37be34fe3339f939318fd28", null ],
    [ "StageDirections", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_dialogue_fragment_type.html#add2955e4603ca535c75c54810c0874b2", null ],
    [ "TechnicalName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_dialogue_fragment_type.html#a36050da4c08d82526fa7efa4ccb9c71e", null ],
    [ "Text", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_dialogue_fragment_type.html#a1756bce47e3a0737c717f707560f72f1", null ]
];