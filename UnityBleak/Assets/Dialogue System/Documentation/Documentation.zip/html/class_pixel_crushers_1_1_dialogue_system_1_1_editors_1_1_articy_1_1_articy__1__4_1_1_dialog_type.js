var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_dialog_type =
[
    [ "Color", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_dialog_type.html#a1247a6a5dd8d93bf2505e8aeb4a45239", null ],
    [ "DisplayName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_dialog_type.html#a7f913d6df87cfdeeb5667c3430663b18", null ],
    [ "ExternalId", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_dialog_type.html#a0f35f70f46da99d3c3f499783ffbbdb7", null ],
    [ "Features", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_dialog_type.html#af474161c0f96daf32bed464df4710ef5", null ],
    [ "Guid", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_dialog_type.html#ae1faca133a22f28f1688bc98a9c24d32", null ],
    [ "ObjectTemplateReference", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_dialog_type.html#adf83b50410e49fb191f76a226e3f57d9", null ],
    [ "ObjectTemplateReferenceName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_dialog_type.html#ac5125cbacbba321ef9b6d811cd35133e", null ],
    [ "Pins", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_dialog_type.html#a03f61cec92db83f3d61f3b237c72b81c", null ],
    [ "PreviewImage", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_dialog_type.html#a801a0266a062b93c80e8c48c22dbfe23", null ],
    [ "References", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_dialog_type.html#a64d21c33c035a0365c80b8f6778c5b37", null ],
    [ "ShortId", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_dialog_type.html#a30cfc7b2bea6f1b2b725b919469e6892", null ],
    [ "TechnicalName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_dialog_type.html#a1e1bcf148d78e6ef9197bfe419c227a0", null ],
    [ "Text", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_dialog_type.html#a1cad3a693cb7ea8bdd89779922a304f8", null ]
];