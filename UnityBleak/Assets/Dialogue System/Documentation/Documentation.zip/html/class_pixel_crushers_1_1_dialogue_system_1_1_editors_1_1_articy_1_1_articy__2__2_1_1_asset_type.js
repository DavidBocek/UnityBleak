var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_asset_type =
[
    [ "AssetFilename", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_asset_type.html#a4d025ed9300b3b9ce7e5c8ef44825940", null ],
    [ "AssetPath", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_asset_type.html#a3f8f5b803827290d637f55f59bb47dc3", null ],
    [ "Color", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_asset_type.html#a3a87fe568ef9907e0a1d82a97fa73fd1", null ],
    [ "DisplayName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_asset_type.html#a6dfb1c408c539fc1a2a142b4132613c3", null ],
    [ "ExternalId", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_asset_type.html#a1bd609174cb2a52a6ac7e8b8f58ad02c", null ],
    [ "Features", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_asset_type.html#a0b1db985480f94bfa756103b30edafed", null ],
    [ "Id", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_asset_type.html#adeb248fd32614ce017f3a9667bd25864", null ],
    [ "ObjectTemplateReference", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_asset_type.html#a611e23437bcbfa456605a58f9b6226f7", null ],
    [ "ObjectTemplateReferenceName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_asset_type.html#a07660282bb0f13eb5d3484c12526c314", null ],
    [ "OriginalSource", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_asset_type.html#a0ea7a83acb4e7ee175dc43ee40e7513f", null ],
    [ "PreviewImage", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_asset_type.html#a23e424f291f62f6dacdb0e4883d8a2b5", null ],
    [ "ShortId", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_asset_type.html#ad23c1710ef3fd7f079a9e7a4b602a3ce", null ],
    [ "TechnicalName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_asset_type.html#a2007e263ae03561e24a7207c90364627", null ],
    [ "Text", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_asset_type.html#a46811269cfe0b2140020e3cb124ff1c1", null ]
];