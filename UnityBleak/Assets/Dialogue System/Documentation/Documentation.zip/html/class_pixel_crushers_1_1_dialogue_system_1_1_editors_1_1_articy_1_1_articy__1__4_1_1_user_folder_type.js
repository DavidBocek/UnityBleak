var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_user_folder_type =
[
    [ "Color", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_user_folder_type.html#ac7030d13f7c54dadf4c7674e78d8e670", null ],
    [ "DisplayName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_user_folder_type.html#a7c1f6cedca0879cb36825ae72f29410f", null ],
    [ "ExternalId", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_user_folder_type.html#abe3e83b1f9458ab5daccd6499e4c7638", null ],
    [ "Guid", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_user_folder_type.html#a3b091867434f73de6c2d64e48bf77b6e", null ],
    [ "ShortId", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_user_folder_type.html#ab11d4c217be65a8848bc3d1bdcca4c9d", null ],
    [ "TechnicalName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_user_folder_type.html#a2b68adacbceca250bcdd134353885d37", null ],
    [ "Text", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_user_folder_type.html#a988201bc0bf0a9b11a9cb83fb6a7e3fa", null ]
];