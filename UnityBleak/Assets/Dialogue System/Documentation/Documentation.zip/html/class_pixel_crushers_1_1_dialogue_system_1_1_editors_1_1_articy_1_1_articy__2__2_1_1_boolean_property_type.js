var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_boolean_property_type =
[
    [ "Name", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_boolean_property_type.html#a5c154a5bc3dbf4cc706fda7b793f4f21", null ],
    [ "Value", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__2__2_1_1_boolean_property_type.html#ac0041f794658f1437da7edf529aa6259", null ]
];