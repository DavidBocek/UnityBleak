var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_note_type =
[
    [ "Color", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_note_type.html#aef9b038c20c74ab7fdfc8d1b2565ce31", null ],
    [ "DisplayName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_note_type.html#abd2e33e21f1da4dfe1f7dc1241538683", null ],
    [ "ExternalId", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_note_type.html#a54607eb13f108854587420d7ce36a9ae", null ],
    [ "Features", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_note_type.html#a74ca971007b3d7be1a8a34ad84fa6fd5", null ],
    [ "Guid", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_note_type.html#a1bc7fef44d46268ce332f2a1f87725d2", null ],
    [ "NoteContent", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_note_type.html#a8c88cc34cd85ebf69ae6f49e3d08bae9", null ],
    [ "ObjectTemplateReference", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_note_type.html#af930dccd12338390e2c331589520c39c", null ],
    [ "ObjectTemplateReferenceName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_note_type.html#af8fb29d14c07c0294b6378450fd78787", null ],
    [ "ShortId", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_note_type.html#a8ee87058282fe42436967fee60b6f4fd", null ],
    [ "TechnicalName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_note_type.html#abba6832e99c4baa7f69b90fdd56a2e92", null ],
    [ "Text", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_note_type.html#ab63e00352f1e432f21d181ed58241460", null ]
];