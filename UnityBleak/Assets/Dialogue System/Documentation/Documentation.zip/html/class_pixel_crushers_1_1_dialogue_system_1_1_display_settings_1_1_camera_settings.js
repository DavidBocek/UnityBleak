var class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_camera_settings =
[
    [ "cameraAngles", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_camera_settings.html#a5ea29dd3922ff09b28ebeda5bf6785e7", null ],
    [ "defaultSequence", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_camera_settings.html#a364db703c1f3e154899bfd2735013723", null ],
    [ "sequencerCamera", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_camera_settings.html#a599ec5301d6e747e8ad32558eba7aa9c", null ]
];