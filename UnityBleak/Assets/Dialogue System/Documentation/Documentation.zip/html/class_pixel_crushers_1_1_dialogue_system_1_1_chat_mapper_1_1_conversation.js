var class_pixel_crushers_1_1_dialogue_system_1_1_chat_mapper_1_1_conversation =
[
    [ "DialogEntries", "class_pixel_crushers_1_1_dialogue_system_1_1_chat_mapper_1_1_conversation.html#a92f6e8fdab5d433f267a89eeb6cf0f7e", null ],
    [ "Fields", "class_pixel_crushers_1_1_dialogue_system_1_1_chat_mapper_1_1_conversation.html#aae54a8943ec977691cf4adf2efb0bfea", null ],
    [ "ID", "class_pixel_crushers_1_1_dialogue_system_1_1_chat_mapper_1_1_conversation.html#a1c9c6b2edb32f8a724a96a3062bf0c6a", null ],
    [ "NodeColor", "class_pixel_crushers_1_1_dialogue_system_1_1_chat_mapper_1_1_conversation.html#a32edd57dbfe154f416510c52c3b5c699", null ]
];