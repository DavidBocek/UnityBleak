var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data =
[
    [ "Connection", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_connection.html", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_connection" ],
    [ "ConnectionRef", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_connection_ref.html", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_connection_ref" ],
    [ "Dialogue", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_dialogue.html", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_dialogue" ],
    [ "DialogueFragment", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_dialogue_fragment.html", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_dialogue_fragment" ],
    [ "Element", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_element.html", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_element" ],
    [ "Entity", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_entity.html", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_entity" ],
    [ "FlowFragment", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_flow_fragment.html", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_flow_fragment" ],
    [ "Hierarchy", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_hierarchy.html", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_hierarchy" ],
    [ "Hub", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_hub.html", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_hub" ],
    [ "Jump", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_jump.html", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_jump" ],
    [ "LocalizableText", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_localizable_text.html", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_localizable_text" ],
    [ "Location", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_location.html", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_location" ],
    [ "Node", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_node.html", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_node" ],
    [ "Pin", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_pin.html", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_pin" ],
    [ "Project", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_project.html", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_project" ],
    [ "Variable", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_variable.html", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_variable" ],
    [ "VariableSet", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_variable_set.html", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_variable_set" ],
    [ "NodeType", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data.html#ab7fac7416fbd230bd416facde39abafa", [
      [ "Dialogue", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data.html#ab7fac7416fbd230bd416facde39abafaa359928afdf6c973ee869e1698023a812", null ],
      [ "DialogueFragment", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data.html#ab7fac7416fbd230bd416facde39abafaa063372e6c641c3f5a7f710d0838193af", null ],
      [ "Hub", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data.html#ab7fac7416fbd230bd416facde39abafaa2e4b7e66cd3715235c82aa017ee1192e", null ],
      [ "Jump", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data.html#ab7fac7416fbd230bd416facde39abafaa101f693f72287a2819a364f64ca1c0ed", null ],
      [ "Connection", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data.html#ab7fac7416fbd230bd416facde39abafaac2cc7082a89c1ad6631a2f66af5f00c0", null ],
      [ "Other", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data.html#ab7fac7416fbd230bd416facde39abafaa6311ae17c1ee52b36e68aaf4ad066387", null ]
    ] ],
    [ "SemanticType", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data.html#a2a2d0fa64baa1f47a640f31405671106", [
      [ "Input", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data.html#a2a2d0fa64baa1f47a640f31405671106a324118a6721dd6b8a9b9f4e327df2bf5", null ],
      [ "Output", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data.html#a2a2d0fa64baa1f47a640f31405671106a29c2c02a361c9d7028472e5d92cd4a54", null ]
    ] ],
    [ "VariableDataType", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data.html#a973c8dfdd8444dd5b4a0403c35a99c56", [
      [ "Boolean", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data.html#a973c8dfdd8444dd5b4a0403c35a99c56a27226c864bac7454a8504f8edb15d95b", null ],
      [ "Integer", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data.html#a973c8dfdd8444dd5b4a0403c35a99c56aa0faef0851b4294c06f2b94bb1cb2044", null ]
    ] ],
    [ "FullVariableName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data.html#aa44d4bfd1b8f049e13be83f6c9cdd712", null ],
    [ "connections", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data.html#a2b4a63f8d2ba1febce22d7b19fe72a58", null ],
    [ "dialogueFragments", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data.html#afcd574e7bd1f73aed4428e2a4405a4ca", null ],
    [ "dialogues", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data.html#a7907cddcf6090434d3fdcc7a166caf4f", null ],
    [ "entities", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data.html#a20d1e116aaf8b2a6e80c20d2b4976fd2", null ],
    [ "flowFragments", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data.html#a09a08599538177e81d853d3be926dbea", null ],
    [ "hierarchy", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data.html#ad7d7b54f4011c3952a2563b91897b489", null ],
    [ "hubs", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data.html#a71cddda75c6b247e22bbbc428a865d73", null ],
    [ "jumps", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data.html#ae9cd3e75892184b67e4b8ce396b214a9", null ],
    [ "locations", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data.html#a3dc47656a608690423c16f12c1750df7", null ],
    [ "project", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data.html#a640548fa08a0de85225724fed5a3dd8b", null ],
    [ "variableSets", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data.html#ae1d808f60637a5b061c34e88fb6d746e", null ],
    [ "ProjectAuthor", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data.html#a4c97c482d096f02bb0f967c4d2329f5f", null ],
    [ "ProjectTitle", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data.html#a9941ad40012ca529221574fe29bba075", null ],
    [ "ProjectVersion", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data.html#a4a5634ae06a0bd2bd326c69d213aa79b", null ]
];