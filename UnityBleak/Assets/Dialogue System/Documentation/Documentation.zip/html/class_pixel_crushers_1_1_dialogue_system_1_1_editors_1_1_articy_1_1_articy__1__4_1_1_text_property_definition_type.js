var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_text_property_definition_type =
[
    [ "AllowsLinebreaks", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_text_property_definition_type.html#a2ae0e806fc2cb4024997fd3fc41e4cc9", null ],
    [ "AllowsLinebreaksSpecified", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_text_property_definition_type.html#ad5ad92b757898c675177018a013dbada", null ],
    [ "BasedOn", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_text_property_definition_type.html#a0dfab9ee1a06fec39008fec14969e741", null ],
    [ "DefaultValue", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_text_property_definition_type.html#a7d4d83d4cd6c4d86e84f0ab2f5655c2f", null ],
    [ "DisallowedChars", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_text_property_definition_type.html#ad222e908d00d510535bd3b98fc297a7d", null ],
    [ "DisallowedCharsSpecified", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_text_property_definition_type.html#a4fe56663896defc3c1652a0aa301c34b", null ],
    [ "DisplayName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_text_property_definition_type.html#a7d5f001714bd7f4825a88494275a8edf", null ],
    [ "Guid", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_text_property_definition_type.html#a4090087b9f0c38d25226526007ed8f14", null ],
    [ "IsLocalized", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_text_property_definition_type.html#a436a0246fce9c770b37afd3338c85f1f", null ],
    [ "IsLocalizedSpecified", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_text_property_definition_type.html#aa11fe4511ae4567f9f24da3b522df205", null ],
    [ "IsMandatory", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_text_property_definition_type.html#adcc7ec54b536970ab4473448fa6fbaab", null ],
    [ "IsMandatorySpecified", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_text_property_definition_type.html#ab436932cdcec86337ac4e7fd8d997946", null ],
    [ "MaxLength", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_text_property_definition_type.html#a368fe53a13550e012321199fb3a0c8fc", null ],
    [ "MaxLengthSpecified", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_text_property_definition_type.html#a536b7af81db1625918576bd3a722b25e", null ],
    [ "PlaceholderValue", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_text_property_definition_type.html#a1ce5aa77f3fbc04eed400c426be1c69b", null ],
    [ "TechnicalName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_text_property_definition_type.html#a9433de8b903aac7c2a564d5adbffd9ad", null ],
    [ "TooltipText", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_text_property_definition_type.html#a4991446b720c6f7f39fe1023082fb736", null ]
];