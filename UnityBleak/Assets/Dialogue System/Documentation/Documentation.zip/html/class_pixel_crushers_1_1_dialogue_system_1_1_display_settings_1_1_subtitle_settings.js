var class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_subtitle_settings =
[
    [ "minSubtitleSeconds", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_subtitle_settings.html#a34d2da71c3eaf9a40b195b89aa32fcd9", null ],
    [ "richTextEmphases", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_subtitle_settings.html#a214ea3f0fc04a00d76d2e2298d355f69", null ],
    [ "showNPCSubtitlesDuringLine", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_subtitle_settings.html#a13af2acc41b92ea29475a57b049c6a3d", null ],
    [ "showNPCSubtitlesWithResponses", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_subtitle_settings.html#a3d3d7703c626084d7718029e3cfadf4f", null ],
    [ "showPCSubtitlesDuringLine", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_subtitle_settings.html#acdcc2810c08bd6330143790e4194c437", null ],
    [ "subtitleCharsPerSecond", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_subtitle_settings.html#afacb25ca007db79b932de7b30aab152d", null ],
    [ "waitForContinueButton", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_subtitle_settings.html#a24cebbb24c2575b11bcffcac27b14b95", null ]
];