var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_boolean_property_type =
[
    [ "Name", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_boolean_property_type.html#a51320d310ea87030b92c3c26138fad17", null ],
    [ "Value", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_boolean_property_type.html#a2d4251af863774322b5617c3ac3c21d3", null ]
];