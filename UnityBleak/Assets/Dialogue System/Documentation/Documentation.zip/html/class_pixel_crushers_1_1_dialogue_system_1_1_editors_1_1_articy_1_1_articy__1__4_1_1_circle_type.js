var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_circle_type =
[
    [ "CenterX", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_circle_type.html#a5beb17cd2df5f706c4f3320acd686a58", null ],
    [ "CenterY", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_circle_type.html#ad502a9dce9b87e2c1cd76085d8f7d7d9", null ],
    [ "Radius", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_circle_type.html#ae8820a252932b93d0ae49ac8fcee1c6e", null ]
];