var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_jump_type =
[
    [ "Color", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_jump_type.html#adfa1579174405c8b80a06970cb1d8e21", null ],
    [ "DisplayName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_jump_type.html#a08676dfe311005b0e86e66bb4b7edeb6", null ],
    [ "ExternalId", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_jump_type.html#ac185d12ad703d0312c5882254ff9f20c", null ],
    [ "Features", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_jump_type.html#a5b5e1db081150fcb94eb681f0f196f93", null ],
    [ "Guid", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_jump_type.html#a69dbb57ec920fabcc975e2e08fa861cd", null ],
    [ "ObjectTemplateReference", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_jump_type.html#a5e41ce914f80b5654ea2e9eed3b21498", null ],
    [ "ObjectTemplateReferenceName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_jump_type.html#a192977680f960896ca508a9962b361c8", null ],
    [ "Pins", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_jump_type.html#a0c4a1a81bebfd2f2809642b085cbfd5f", null ],
    [ "ShortId", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_jump_type.html#a303693358250f5c56176ffa2cdc3b5f0", null ],
    [ "Target", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_jump_type.html#a1990b5371aacac27432cd41db8c7aae5", null ],
    [ "TechnicalName", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_jump_type.html#a5e960e6c120a3ba7b541606883ab65b0", null ],
    [ "Text", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_jump_type.html#a5c8d2c29bb5ae3084b190b53cc88569d", null ]
];