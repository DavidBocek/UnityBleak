var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_connection_ref_type =
[
    [ "GuidRef", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_connection_ref_type.html#a4755626d4a657e8299df2dc845005c9b", null ],
    [ "PinRef", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_connection_ref_type.html#acadc56733fdb8785c8b24589accc0ade", null ],
    [ "Value", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy__1__4_1_1_connection_ref_type.html#a95e8fb9e82cc44b7489be77413a0f29c", null ]
];